# HOPFL
A program to implement the semantics of a guarded higher order probabilistic language (guarded HOPFL).

